﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
        public static class TriangleSolver
        {
            public static string Analyze(int no1, int no2, int no3)
            {
                String x = string.Empty;
                if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
                {
                    x = "All dimensions forms a Traingle";
                    if (no1 == no2 && no2 == no3)
                    {
                        x += "\n Type = Equilateral";
                    }
                    else if (no1 == no2 || no1 == no2 || no3==no1)
                    {
                        x += "\n Type = Isosceles";
                    }
                    else
                    {
                        x += "\n Type = Scalene";
                    }
                    return x;
                }
                else
                {
                    x= "Dimensions does not creates an triangle";
                return x;
                }
            }
        }
}
