﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Program
    {
        public static void Main(string[] arg)
        {
            bool flag = false;
            do
            {
                int z = MenuValidation();
                if(z==1)
                {
                    int a = ValidattionOfInput("first side");
                    int b = ValidattionOfInput("second side");
                    int c = ValidattionOfInput("third side");
                    Console.WriteLine(TriangleSolver.Analyze(a, b, c));
                }
                else if(z==2)
                {
                    flag = true;
                    Environment.Exit(0);
                }
            } while (flag == false);
        }
        public static int MenuValidation()
        {
            int choice = 0;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.WriteLine("1 = To Enter three dimensions of Triangle");
                Console.WriteLine("2 = Exit");
                Console.Write("Your selection? : ");

                str = Console.ReadLine();
                if (!int.TryParse(str, out choice))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else if (!((choice > 0) && (choice <= 2)))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else
                {
                    flag = true;
                }
            } while (flag == false);
            return choice;
        }
        public static int ValidattionOfInput(string ts)
        {
            int no = 1;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.Write("Provide {0} of triangle(valid range >0) : ", ts);
                str = Console.ReadLine();
                if (!int.TryParse(str, out no))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else if (!(no > 0))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else
                {
                    flag = true;
                }
            } while (flag == false);
            return no;
        }
    }
}
