﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_2;
using NUnit.Framework;

namespace Assignment_2_testcase
{
    [TestFixture]
    public class Class1
    {
            [Test]
            public void TriAnalyze_FirstInput3_SecondInput6_ThirdInput9_ExpectedOutput_NotTriangle()
            {
                
                int no1 = 3;
                int no2 = 6;
                int no3 = 9;

                string x = String.Empty;
                if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
                {
                    x = "All dimensions forms a Traingle";
                    if (no1 == no2 && no2 == no3)
                    {
                        x += "\n Type = Equilateral";
                    }
                    else if (no1 == no2 || no1 == no2 || no3 == no1)
                    {
                        x += "\n Type = Isosceles";
                    }
                    else
                    {
                        x += "\n Type = Scalene";
                    }
                }
                else
                {
                    x = "Dimensions does not creates an triangle";
                }
                    
                string op = TriangleSolver.Analyze(no1,no2,no3);

                
                Assert.AreEqual(op, x);
            }

        [Test]
        public void TriAnalyze_FirstInput2_SecondInput3_ThirdInput4_ExpectedOutput_Scalene()
        {

            int no1 = 2;
            int no2 = 3;
            int no3 = 4;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }
        
        [Test]
        public void TriAnalyze_FirstInput3_SecondInput3_ThirdInput3_ExpectedOutput_Equilateral()
        {

            int no1 = 3;
            int no2 = 3;
            int no3 = 3;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }
        
        [Test]
        public void TriAnalyze_FirstInput4_SecondInput4_ThirdInput2_ExpectedOutput_Isosceles()
        {

            int no1 = 4;
            int no2 = 4;
            int no3 = 2;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }

        // AGAIN
        [Test]
        public void TriAnalyze_FirstInput4_SecondInput8_ThirdInput12_ExpectedOutput_NotTriangle()
        {

            int no1 = 4;
            int no2 = 8;
            int no3 = 12;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }

        [Test]
        public void TriAnalyze_FirstInput3_SecondInput4_ThirdInput5_ExpectedOutput_Scalene()
        {

            int no1 = 3;
            int no2 = 4;
            int no3 = 5;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }

        [Test]
        public void TriAnalyze_FirstInput5_SecondInput5_ThirdInput5_ExpectedOutput_Equilateral()
        {

            int no1 = 5;
            int no2 = 5;
            int no3 = 5;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }

        [Test]
        public void TriAnalyze_FirstInput2_SecondInput2_ThirdInput1_ExpectedOutput_Isosceles()
        {

            int no1 = 2;
            int no2 = 2;
            int no3 = 1;

            string x = String.Empty;
            if (((no1 + no2) > no3) && ((no1 + no3) > no2) && ((no2 + no3) > no1))
            {
                x = "All dimensions forms a Traingle";
                if (no1 == no2 && no2 == no3)
                {
                    x += "\n Type = Equilateral";
                }
                else if (no1 == no2 || no1 == no2 || no3 == no1)
                {
                    x += "\n Type = Isosceles";
                }
                else
                {
                    x += "\n Type = Scalene";
                }
            }
            else
            {
                x = "Dimensions does not creates an triangle";
            }

            string op = TriangleSolver.Analyze(no1, no2, no3);


            Assert.AreEqual(op, x);
        }
    }
}
